#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SRC="$SCRIPT_DIR/pdf-learning-material-analyzer"
DEST="$HOME/.agents/skills/pdf-learning-material-analyzer"
mkdir -p "$HOME/.agents/skills"
rm -rf "$DEST"
cp -R "$SRC" "$DEST"
echo "Installed to: $DEST"
echo "Restart Codex if the skill does not appear immediately."
