#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="${1:-$(pwd)}"
SRC="$SCRIPT_DIR/pdf-learning-material-analyzer"
DEST="$PROJECT_DIR/.agents/skills/pdf-learning-material-analyzer"
mkdir -p "$PROJECT_DIR/.agents/skills"
rm -rf "$DEST"
cp -R "$SRC" "$DEST"
echo "Installed to: $DEST"
echo "Run Codex from the project directory or a subdirectory. Restart Codex if the skill does not appear immediately."
