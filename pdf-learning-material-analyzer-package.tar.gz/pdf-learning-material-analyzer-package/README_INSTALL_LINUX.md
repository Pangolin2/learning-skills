# PDF Learning Material Analyzer Skill

本包用于在 Linux 环境中为 Codex 配置一个 PDF 学习材料整理 Skill。

## 包含内容

```text
pdf-learning-material-analyzer-package/
├── pdf-learning-material-analyzer/
│   ├── SKILL.md
│   ├── agents/
│   │   └── openai.yaml
│   └── references/
│       ├── output_templates.md
│       ├── question_rules.md
│       └── lab_rules.md
├── AGENTS.example.md
├── install_user_scope.sh
├── install_project_scope.sh
└── README_INSTALL_LINUX.md
```

## 安装到用户级目录

用户级安装后，任意项目都可以使用该 Skill。

```bash
unzip pdf-learning-material-analyzer-package.zip
cd pdf-learning-material-analyzer-package
bash install_user_scope.sh
```

安装位置：

```text
~/.agents/skills/pdf-learning-material-analyzer/
```

## 安装到当前项目

项目级安装后，只在当前项目或其子目录中使用该 Skill。

```bash
unzip pdf-learning-material-analyzer-package.zip
cd pdf-learning-material-analyzer-package
bash install_project_scope.sh /path/to/your/project
```

安装位置：

```text
/path/to/your/project/.agents/skills/pdf-learning-material-analyzer/
```

## 可选：添加项目级 AGENTS.md

如果你希望该项目长期遵守“中文输出、只整理不执行、保留原始代码”等规则，可以将示例文件复制到项目根目录：

```bash
cp AGENTS.example.md /path/to/your/project/AGENTS.md
```

## 验证 Skill 是否可用

进入包含 PDF 资料的项目目录：

```bash
cd /path/to/your/project
codex
```

在 Codex 中输入：

```text
/skills
```

如果看到 `pdf-learning-material-analyzer`，说明已识别。

也可以直接显式调用：

```text
使用 $pdf-learning-material-analyzer 分析当前目录下已经分类好的 PDF 学习材料。默认中文输出，不需要保留页码。请生成多个 Markdown 文件，包括课程总结、课程知识框架、章节内容整理、实验内容整理、实验代码与命令提取、试题设计初稿和后续内容生产建议。实验命令只整理，不执行，不修改原始代码。
```

## 推荐资料目录结构

```text
your_project/
├── materials/
│   ├── theory/
│   │   ├── 01_理论介绍.pdf
│   │   └── 02_核心技术.pdf
│   ├── lab/
│   │   ├── 01_实验手册.pdf
│   │   └── 02_实验指导.pdf
│   └── extra/
│       └── 补充资料.pdf
└── AGENTS.md
```

## 推荐调用 Prompt

```text
使用 $pdf-learning-material-analyzer 整理 ./materials 下的 PDF 学习材料，输出到 output_md。重点分析章节结构、课程总结、知识框架、实验流程和原始代码命令。只整理，不执行实验。
```

## 常见问题

### 1. Codex 没有显示该 Skill

检查目录是否正确：

```bash
ls ~/.agents/skills/pdf-learning-material-analyzer/SKILL.md
```

或者项目级：

```bash
ls .agents/skills/pdf-learning-material-analyzer/SKILL.md
```

如果路径正确但没有识别，重启 Codex。

### 2. 多个项目都要用

安装到用户级目录：

```bash
mkdir -p ~/.agents/skills
cp -r pdf-learning-material-analyzer ~/.agents/skills/
```

### 3. 只想某个项目使用

安装到项目目录：

```bash
mkdir -p /path/to/project/.agents/skills
cp -r pdf-learning-material-analyzer /path/to/project/.agents/skills/
```

### 4. 需要卸载

用户级：

```bash
rm -rf ~/.agents/skills/pdf-learning-material-analyzer
```

项目级：

```bash
rm -rf /path/to/project/.agents/skills/pdf-learning-material-analyzer
```
