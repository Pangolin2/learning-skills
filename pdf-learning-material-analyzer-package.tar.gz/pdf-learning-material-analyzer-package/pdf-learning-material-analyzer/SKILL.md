---
name: pdf-learning-material-analyzer
description: Analyze categorized local PDF learning materials, including theory materials, textbooks, course documents, and lab manuals. Extract Chinese course summaries, knowledge frameworks, chapter notes, lab procedures, original code and commands, default question drafts, and structured Markdown files. Use when asked to organize PDF learning materials into md files for summaries, teaching, experiments, questions, or follow-up content production.
---

# PDF Learning Material Analyzer Skill

## Purpose

Analyze local PDF learning materials and organize them into structured Markdown files.

The input materials may include textbooks, course theory materials, chapter-based learning materials, experiment manuals, lab guides, hands-on operation documents, and mixed theory-plus-experiment PDFs.

The output should support later work such as course summary, knowledge framework, chapter notes, teaching preparation, experiment manual creation, command and code extraction, question design, review material generation, and follow-up Markdown documentation.

## Default Behavior

Use Chinese as the default output language.

Keep common technical terms in English when appropriate, such as Docker, Python, API, CLI, Linux, GPU, NPU, Dataset, Model, Inference, Training, Fine-tuning, Kubernetes, Hadoop, Spark, RAG, and Agent.

Do not translate technical commands, code, file paths, parameter names, package names, or configuration keys.

## Input Assumptions

The user may provide multiple PDF files.

PDF files are usually already categorized by directory or filename, for example:

```text
materials/
├── theory/
├── lab/
├── textbook/
├── experiment/
└── extra/
```

Respect the existing folder structure and filename meaning. Do not aggressively reclassify documents if the user has already organized them.

If several PDFs exist, process them as a document set. If some PDFs are clearly theory materials and others are lab materials, keep them separated in the output.

## Key Requirements

Follow these defaults unless the user says otherwise:

1. Multiple PDF files may be processed.
2. The files are already roughly categorized.
3. The source is usually exported from textbooks, courseware, or lab manuals.
4. The content may include theory introductions and experiment manuals.
5. Page numbers are not required by default.
6. The main task is to analyze chapter structure and organize content.
7. First analysis should be as complete as reasonably possible.
8. Output course summary and course framework by default.
9. Question design uses a default general format.
10. Question format may be adjusted later for different scenarios.
11. Lab content should focus on runnable experiments and practical operation.
12. Extract code, commands, configuration, and paths as completely as possible.
13. Do not damage, rewrite, or silently optimize original code.
14. Do not run experiment commands for verification.
15. Generate multiple Markdown files when appropriate.
16. Do not apply strong domain-specific assumptions.
17. Adapt terminology and structure according to the actual topic of the materials.

## Safety and Preservation Rules

Do not delete original PDF files.

Do not modify original PDF files.

Do not overwrite existing Markdown outputs unless the user explicitly allows it.

Do not execute experiment commands from the lab manual.

Do not install dependencies unless the user explicitly requests it.

Do not run training, inference, deployment, database, system modification, cleanup, or other environment-changing commands.

Safe actions include listing files, reading filenames, extracting text from PDFs, inspecting document structure, creating Markdown output files, creating output directories, and copying extracted code into Markdown files.

When extracting code, preserve the original version first. If an improved version is suggested, place it in a separate section named:

```markdown
## 可选优化建议
```

Never mix optimized code with the original extracted code.

## Workflow

### Step 1: Scan Input Files

Search the workspace for PDF files.

Recommended command:

```bash
find . -maxdepth 5 -type f \( -iname "*.pdf" -o -iname "*.PDF" \)
```

Record file path, filename, parent directory, likely document type, and whether it appears to be theory, lab, textbook, experiment, or supplementary material.

Do not require page numbers in the final output.

### Step 2: Understand the Material Set

Analyze the file set as a whole.

Identify the overall topic, target learning direction, major modules, theory materials, experiment materials, supporting materials, repeated or overlapping content, missing dependencies, and unclear parts.

Use existing folder names and filenames as strong signals.

Common categories:

| Category | Meaning |
|---|---|
| Theory | Concepts, principles, architecture, background |
| Textbook | Systematic course content |
| Lab | Experiment operation and hands-on steps |
| Experiment | Runnable tasks and procedures |
| Case | Scenario-based explanation |
| Extra | Supplementary or reference material |
| Unknown | Cannot be clearly identified |

### Step 3: Extract Text

Extract PDF text while preserving headings, chapter names, section names, ordered lists, tables when possible, code blocks, commands, configuration snippets, file paths, parameter names, environment requirements, expected outputs, and error messages.

If the PDF contains scanned pages or image-only content, mark it clearly:

```markdown
> 该部分可能来自扫描页或图片内容，文本提取不完整，需要人工复核。
```

Do not invent missing content.

### Step 4: Analyze Chapter Structure

For theory and textbook PDFs, identify course title, chapter structure, section structure, learning objectives, key concepts, main explanations, knowledge dependencies, important comparisons, application scenarios, and summary points.

Use this structure:

```markdown
# 章节结构分析

| 序号 | 章节/模块 | 主要内容 | 内容类型 | 后续用途 |
|---:|---|---|---|---|
| 1 | | | 理论/实验/混合 | 总结/讲稿/试题/实验 |
```

Do not rely on page numbers by default.

### Step 5: Analyze Theory Content

For each theory chapter, organize content into:

```markdown
## 章节名称

### 1. 本章定位

说明本章在整套材料中的作用。

### 2. 学习目标

- ...

### 3. 核心概念

| 概念 | 解释 | 相关内容 |
|---|---|---|
| | | |

### 4. 知识点梳理

按照原始材料逻辑进行整理。

### 5. 重点机制或流程

如果材料中包含架构、流程、算法、系统机制，需要单独提炼。

### 6. 对比分析

如果材料中存在多个概念、技术、工具或方案，需要整理对比表。

### 7. 应用场景

总结材料中提到的典型使用场景。

### 8. 易混淆点

整理容易误解或需要重点强调的内容。

### 9. 后续可生成内容

说明该章节适合继续生成课程总结、逐字稿、PPT 大纲、试题、案例或实验说明。
```

### Step 6: Analyze Lab Content

For experiment manuals or lab sections, organize content into:

```markdown
## 实验名称

### 1. 实验目标

### 2. 实验背景

### 3. 实验环境

| 项目 | 内容 |
|---|---|
| 操作系统 | |
| 硬件要求 | |
| 软件依赖 | |
| 编程语言 | |
| 框架/工具 | |
| 数据集 | |
| 模型/镜像/服务 | |
| 账号/权限 | |

如果材料中没有明确说明，填写“原文未明确说明”。

### 4. 实验文件与目录

```text
project/
├── ...
└── ...
```

如果原文没有完整目录结构，根据材料中出现的路径进行整理，并标记为“根据原文路径整理”。

### 5. 实验流程概览

| 步骤 | 任务 | 说明 |
|---:|---|---|
| 1 | | |
| 2 | | |

### 6. 详细操作步骤

#### Step 1：步骤名称

原始命令：

```bash
...
```

说明：

预期结果：

注意事项：

### 7. 结果验证方法

| 检查项 | 检查方式 | 预期结果 |
|---|---|---|
| | | |

### 8. 常见问题与排查

| 现象 | 可能原因 | 处理建议 |
|---|---|---|
| | | |

### 9. 实验总结

总结该实验训练的能力、涉及的知识点和适合考核的内容。

### 10. 可选扩展

仅整理合理扩展方向，不要替换原始实验。
```

## Code and Command Extraction Rules

Create a dedicated Markdown file for extracted code and commands:

```text
05_实验代码与命令提取.md
```

Extract code as completely as possible.

Preserve original command order, original comments, original indentation, original paths, original parameters, original environment variables, original filenames, original code blocks, and original configuration snippets.

Use clear labels:

```markdown
## 来源文件：xxx.pdf

## 实验：xxx

### 代码块 1：环境检查

```bash
...
```

### 代码块 2：运行脚本

```bash
...
```

### 配置文件片段

```json
...
```
```

If code appears incomplete, mark:

```markdown
> 原文代码片段可能不完整，需要结合上下文或源文件复核。
```

If a command may modify the environment, mark:

```markdown
> 注意：该命令可能修改环境。当前 Skill 只负责整理，不执行该命令。
```

Do not correct code automatically. If obvious issues are found, put them in a separate section:

```markdown
## 代码风险与人工复核建议

| 代码/命令 | 可能问题 | 建议 |
|---|---|---|
| | | |
```

## Output Directory

Default output directory:

```text
output_md/
```

If the directory already exists, create a timestamped directory:

```text
output_md_YYYYMMDD_HHMM/
```

Recommended output files:

```text
output_md/
├── 00_资料清单与处理说明.md
├── 01_课程总结.md
├── 02_课程知识框架.md
├── 03_章节内容整理.md
├── 04_实验内容整理.md
├── 05_实验代码与命令提取.md
├── 06_试题设计初稿.md
├── 07_后续内容生产建议.md
└── README.md
```

## Output Templates

Use the detailed output templates in `references/output_templates.md` when generating files.

Use the lab rules in `references/lab_rules.md` when processing experiments.

Use the question rules in `references/question_rules.md` when generating default questions.

## Topic Adaptation Rules

Do not hard-code a specific domain. Adapt to the actual material topic.

Examples:

- If the material is about AI, extract models, algorithms, frameworks, datasets, training, inference, deployment, and evaluation.
- If the material is about big data, extract storage, computing, scheduling, data processing, components, and scenarios.
- If the material is about cloud, extract architecture, services, networking, security, deployment, and operations.
- If the material is about programming, extract syntax, libraries, examples, debugging, and project structure.
- If the material is about network or telecom, extract architecture, protocols, devices, configurations, and troubleshooting.

Only adapt the structure and terminology. Do not invent extra domain content.

## Quality Checklist

Before finishing, check:

- Multiple PDFs were considered as a material set.
- Existing directory classification was respected.
- Default output is Chinese.
- Course summary was generated.
- Knowledge framework was generated.
- Chapter structure was analyzed.
- Lab content was separated from theory content.
- Original code and commands were preserved.
- Experiment commands were not executed.
- Original code was not silently modified.
- Question draft was generated in a general format.
- Missing or unclear content was marked.
- Multiple Markdown files were created.
- README explains the output structure.

## Final Response Format

After completing the task, respond in Chinese using this format:

```markdown
已完成 PDF 学习材料整理。

## 输入资料

- 处理的 PDF 文件数量：
- 理论类资料：
- 实验类资料：
- 其他资料：

## 输出目录

- `output_md/`

## 已生成文件

- `00_资料清单与处理说明.md`
- `01_课程总结.md`
- `02_课程知识框架.md`
- `03_章节内容整理.md`
- `04_实验内容整理.md`
- `05_实验代码与命令提取.md`
- `06_试题设计初稿.md`
- `07_后续内容生产建议.md`
- `README.md`

## 处理说明

- 是否包含理论内容：
- 是否包含实验内容：
- 是否包含代码/命令：
- 是否存在需要人工复核的内容：

## 后续建议

- 可继续生成详细逐字稿。
- 可继续生成特定格式试题。
- 可继续把实验内容整理成标准实验手册。
- 可继续提取操作清单和排错手册。
```
