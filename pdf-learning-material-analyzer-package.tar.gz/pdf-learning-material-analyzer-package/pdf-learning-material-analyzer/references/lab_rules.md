# Lab Processing Rules

## General Rules

1. Only organize lab content. Do not execute lab commands.
2. Do not verify commands by running them.
3. Do not install packages.
4. Do not start services.
5. Do not run training, inference, deployment, database, cleanup, or system modification commands.
6. Preserve original commands, code, paths, parameters, comments, indentation, and order as much as possible.
7. If the source code appears incomplete, mark it as incomplete rather than repairing it silently.
8. If you suggest improvements, place them in a separate “可选优化建议” section.

## Required Lab Sections

For each experiment, extract:

- 实验名称
- 实验目标
- 实验背景
- 实验环境
- 输入文件与目录结构
- 实验流程概览
- 详细操作步骤
- 原始命令和代码
- 结果验证方法
- 常见问题与排查
- 实验总结
- 可选扩展

## Environment Extraction

When present, extract:

- operating system
- hardware
- CPU/GPU/NPU
- memory/storage
- Python version
- framework version
- container image
- dataset
- model
- service endpoint
- permissions
- network requirement

If the source does not specify a field, write “原文未明确说明”.

## Code Risk Notes

Mark commands that may modify the environment, such as:

- rm, mv, chmod, chown
- pip install, conda install, apt/yum/dnf install
- docker run with privileged options
- systemctl commands
- database modification commands
- training or deployment commands
- commands that write to system directories

Use this note:

> 注意：该命令可能修改环境。当前 Skill 只负责整理，不执行该命令。
