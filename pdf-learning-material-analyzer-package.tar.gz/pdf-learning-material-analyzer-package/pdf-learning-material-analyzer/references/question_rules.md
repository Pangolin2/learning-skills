# Question Design Rules

When generating default questions:

1. Use a general training-style format.
2. Do not bind questions to a specific certification unless requested.
3. Each question must include answer, explanation, knowledge point, difficulty, and corresponding chapter.
4. Difficulty must be one of: 基础, 较深, 深入.
5. Multiple-choice questions should usually have two or three correct answers.
6. Wrong options should be plausible and related to the same topic.
7. Avoid questions that are too obvious.
8. Practical questions should focus on operation logic, command understanding, result verification, or troubleshooting.
9. Do not create questions based on unsupported assumptions.
10. If the material does not provide enough basis for a question, mark the question as requiring manual review.

## Recommended Question Mix

For a complete first-pass question draft, use:

- Single-choice questions: 30%
- Multiple-choice questions: 25%
- True/false questions: 20%
- Fill-in-the-blank questions: 10%
- Short-answer questions: 10%
- Practical questions: 5%

Adjust according to the material type. If the material is lab-heavy, increase practical questions.

## Multiple-Choice Style

Use wording such as:

- “以下哪几项……”
- “以下哪几项理解是合理的？”
- “以下哪几项因素通常需要重点分析？”
- “以下哪几项属于……？”
- “以下哪几项排查方向较为合理？”

## Explanation Requirements

For single-choice and multiple-choice questions, explain why the correct options are correct and why the distractors are not appropriate.

For practical questions, include scoring points.
